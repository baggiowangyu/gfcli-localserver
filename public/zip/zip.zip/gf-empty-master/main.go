package main

import (
	_ "github.com/gogf/gf-empty/boot"
	_ "github.com/gogf/gf-empty/router"
	"github.com/gogf/gf/frame/g"
)

func main() {
	g.Server().Run()
}
